var class_esri_1_1_file_g_d_b_1_1_envelope =
[
    [ "Envelope", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a4d23fb61a13a22accc7e89d0025e520d", null ],
    [ "Envelope", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a67c5773a418bacaee0e7ae1a73071d78", null ],
    [ "SetEmpty", "class_esri_1_1_file_g_d_b_1_1_envelope.html#ac1112d3259b71d158d3905c8186811f7", null ],
    [ "xMin", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a799441de3894232c74f8d95642c3bb82", null ],
    [ "yMin", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a1266ddd125a4faef04a70ec90952b7f5", null ],
    [ "zMin", "class_esri_1_1_file_g_d_b_1_1_envelope.html#affa7d34b9352c993543f236a3baa65e3", null ],
    [ "xMax", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a4627ddeeac48c9b917e96eb6c9fa47f9", null ],
    [ "yMax", "class_esri_1_1_file_g_d_b_1_1_envelope.html#a3d4eb345626710e93dae51691a8cae6d", null ],
    [ "zMax", "class_esri_1_1_file_g_d_b_1_1_envelope.html#ae882dfe50dca321c3820f267cd84ed14", null ],
    [ "IsEmpty", "class_esri_1_1_file_g_d_b_1_1_envelope.html#af18e067523548a5abc0d6dfda85d3a75", null ]
];