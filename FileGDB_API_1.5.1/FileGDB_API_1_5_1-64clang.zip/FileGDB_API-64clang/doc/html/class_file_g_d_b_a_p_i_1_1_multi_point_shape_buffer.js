var class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer =
[
    [ "GetExtent", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#a243f729894284c63dd37ccbdc5bb4b34", null ],
    [ "GetNumPoints", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#aee06851c18c6ed7179c692b92554e88a", null ],
    [ "GetPoints", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#afcf1ee5fc522c30ddce3d6256aaea12f", null ],
    [ "GetZExtent", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#a8603fa05941fdb73cb9737324e19117a", null ],
    [ "GetZs", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#ae63fef58d296242c6d0cbdcad14ba0ee", null ],
    [ "GetMExtent", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#acdb6be2f5ceeb34b3abb000a453490c7", null ],
    [ "GetMs", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#ab4921efb438af5d4edfb677aa90e34e3", null ],
    [ "GetIDs", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#a161d61c08a7679ec7e77dfcb6cd53629", null ],
    [ "Setup", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#a8196fd77d21e9cd8b7d4539d62ca8c10", null ],
    [ "CalculateExtent", "class_file_g_d_b_a_p_i_1_1_multi_point_shape_buffer.html#acf37660ffd8b6e440e8860b0812342db", null ]
];