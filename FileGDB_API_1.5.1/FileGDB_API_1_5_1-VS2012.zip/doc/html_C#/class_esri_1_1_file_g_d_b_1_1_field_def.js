var class_esri_1_1_file_g_d_b_1_1_field_def =
[
    [ "FieldDef", "class_esri_1_1_file_g_d_b_1_1_field_def.html#a58711af2b6f5dcb7c7b91b302d57a51f", null ],
    [ "Name", "class_esri_1_1_file_g_d_b_1_1_field_def.html#aeb618b987683c4530dfbe2760aa7b472", null ],
    [ "Alias", "class_esri_1_1_file_g_d_b_1_1_field_def.html#a820b20460d213741c8adbe88d463d099", null ],
    [ "Type", "class_esri_1_1_file_g_d_b_1_1_field_def.html#a8124d77c033a60699664b66b14ac427d", null ],
    [ "Length", "class_esri_1_1_file_g_d_b_1_1_field_def.html#ae459c4f2ffca08214eca4b39ef764040", null ],
    [ "IsNullable", "class_esri_1_1_file_g_d_b_1_1_field_def.html#abbcb06554d75340a9b6145cdbdbd97e0", null ],
    [ "geometryDef", "class_esri_1_1_file_g_d_b_1_1_field_def.html#a6b1fb44cf6e11a16c4d3e5a01078c112", null ]
];