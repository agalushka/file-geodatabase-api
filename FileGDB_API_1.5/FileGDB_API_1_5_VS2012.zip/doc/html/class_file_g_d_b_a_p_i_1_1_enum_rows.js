var class_file_g_d_b_a_p_i_1_1_enum_rows =
[
    [ "EnumRows", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#a62603b28aeb85ac50578f1141a779142", null ],
    [ "~EnumRows", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#a3498700afdb83d76734cd86ede5230b8", null ],
    [ "Next", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#a846493dfcfb80e23f6e81d0c3398af8a", null ],
    [ "Close", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#ad3a9a1926b4a1821714a02c36b9d47e5", null ],
    [ "GetFieldInformation", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#a5947152dfd0027aa37b54d1d71a20505", null ],
    [ "GetFields", "class_file_g_d_b_a_p_i_1_1_enum_rows.html#ab8ef207f2c4378618e481e9d8b86cfcf", null ]
];