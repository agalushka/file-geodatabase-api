var class_esri_1_1_file_g_d_b_1_1_geometry_def =
[
    [ "GeometryDef", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html#afa61d1911ccba9f43a19e0e4625c33d5", null ],
    [ "geometryType", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html#a5f5852c00a2938c66abec85f030e4d78", null ],
    [ "HasZ", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html#a48edf6defe79eefd6f94b6df27531f0a", null ],
    [ "HasM", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html#a0d61091e4e9a28b3b7540428d6884727", null ],
    [ "spatialReference", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html#ab577a630fe3d5e0feff96d70ea9884f6", null ]
];