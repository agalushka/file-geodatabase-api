var class_esri_1_1_file_g_d_b_1_1_spatial_reference_info =
[
    [ "SpatialReferenceInfo", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html#a984370703001ec5f414e22d538bad3b2", null ],
    [ "auth_name", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html#ae5d44db2a3bd9898f4e42eeb1f516c3f", null ],
    [ "auth_srid", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html#a00d9b9e4e7717780e2c2396071c72bb5", null ],
    [ "srtext", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html#aa4dfb112392b2e4760a607058c7b7553", null ],
    [ "srname", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html#a8b294ab132b1caa353db87e23fe9abd2", null ]
];