var hierarchy =
[
    [ "Esri::FileGDB::ByteArray", "class_esri_1_1_file_g_d_b_1_1_byte_array.html", null ],
    [ "Esri::FileGDB::Envelope", "class_esri_1_1_file_g_d_b_1_1_envelope.html", null ],
    [ "Esri::FileGDB::ErrorInfo", "class_esri_1_1_file_g_d_b_1_1_error_info.html", null ],
    [ "Esri::FileGDB::FieldDef", "class_esri_1_1_file_g_d_b_1_1_field_def.html", null ],
    [ "Esri::FileGDB::FileGDBException", "class_esri_1_1_file_g_d_b_1_1_file_g_d_b_exception.html", null ],
    [ "Esri::FileGDB::Geodatabase", "class_esri_1_1_file_g_d_b_1_1_geodatabase.html", null ],
    [ "Esri::FileGDB::GeometryDef", "class_esri_1_1_file_g_d_b_1_1_geometry_def.html", null ],
    [ "Esri::FileGDB::IndexDef", "class_esri_1_1_file_g_d_b_1_1_index_def.html", null ],
    [ "Esri::FileGDB::Raster", "class_esri_1_1_file_g_d_b_1_1_raster.html", null ],
    [ "Esri::FileGDB::Row", "class_esri_1_1_file_g_d_b_1_1_row.html", null ],
    [ "Esri::FileGDB::ShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_shape_buffer.html", [
      [ "Esri::FileGDB::MultiPartShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_part_shape_buffer.html", null ],
      [ "Esri::FileGDB::MultiPatchShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_patch_shape_buffer.html", null ],
      [ "Esri::FileGDB::MultiPointShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_multi_point_shape_buffer.html", null ],
      [ "Esri::FileGDB::PointShapeBuffer", "class_esri_1_1_file_g_d_b_1_1_point_shape_buffer.html", null ]
    ] ],
    [ "Esri::FileGDB::SpatialReference", "class_esri_1_1_file_g_d_b_1_1_spatial_reference.html", null ],
    [ "Esri::FileGDB::SpatialReferenceInfo", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info.html", null ],
    [ "Esri::FileGDB::SpatialReferenceInfoCollection", "class_esri_1_1_file_g_d_b_1_1_spatial_reference_info_collection.html", null ],
    [ "Esri::FileGDB::Table", "class_esri_1_1_file_g_d_b_1_1_table.html", null ]
];